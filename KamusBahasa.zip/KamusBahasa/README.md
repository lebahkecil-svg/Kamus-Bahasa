# Kamus Bahasa dan Percakapan
Android native (Kotlin + Compose). Lihat langkah build di GitHub pada chat.
