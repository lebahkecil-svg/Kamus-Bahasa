package com.kamus.bahasa

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Progress(c: Context) {
    private val sp = c.getSharedPreferences("progress", 0)
    fun best(l: String) = sp.getInt("${l}_best", 0)
    fun tries(l: String) = sp.getInt("${l}_tries", 0)
    fun save(l: String, s: Int) {
        sp.edit().putInt("${l}_best", maxOf(best(l), s)).putInt("${l}_tries", tries(l) + 1).apply()
    }
}

class Speaker(c: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(c) { ready = it == TextToSpeech.SUCCESS }
    fun say(t: String, indo: Boolean) {
        if (!ready) return
        tts.language = if (indo) Locale("id", "ID") else Locale.US
        tts.speak(t.substringBefore(" / "), TextToSpeech.QUEUE_FLUSH, null, "kamus")
    }
}

lateinit var speaker: Speaker

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Progress(this)
        speaker = Speaker(this)
        words = loadWords(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFF5B800), onPrimary = Color.Black,
                background = Color(0xFF0B1424), surface = Color(0xFF0B1424),
                surfaceVariant = Color(0xFF1C2B4A), onSurfaceVariant = Color.White
            )) { App(p) }
        }
    }
}

@Composable
fun App(p: Progress) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("📖" to "Kamus", "📘" to "Grammar", "💬" to "Percakapan", "✍️" to "Latihan", "📊" to "Progres")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (e, n) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(e) }, label = { Text(n, fontSize = 10.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Kamus(); 1 -> GrammarTab(); 2 -> Percakapan(); 3 -> Latihan(p); else -> Progres(p)
            }
        }
    }
}

@Composable
fun Kamus() {
    var enId by remember { mutableStateOf(true) }
    var q by remember { mutableStateOf("") }
    val list = remember(enId) {
        val pairs = if (enId) words else words.flatMap { w -> w.second.split(" / ").map { it to w.first } }
        pairs.groupBy({ it.first.trim() }, { it.second.trim() })
            .map { (k, v) -> k to v.distinct().take(6).joinToString(" / ") }
            .sortedBy { it.first.lowercase() }
    }
    val r = list.filter { it.first.contains(q, true) || it.second.contains(q, true) }
    Column(Modifier.padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = enId, onClick = { enId = true }, label = { Text("Inggris → Indonesia") })
            FilterChip(selected = !enId, onClick = { enId = false }, label = { Text("Indonesia → Inggris") })
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp),
            label = { Text(if (enId) "Cari kata Inggris / arti" else "Cari kata Indonesia / arti") }, singleLine = true)
        Text("${r.size} kata" + if (words.size > baseWords.size) " • sumber tambahan: FreeDict (WikDict)" else "", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp)) {
            items(r) { w ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(start = 14.dp, top = 4.dp, bottom = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.first, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                            Text("🔊", Modifier.clickable { speaker.say(w.first, !enId) }.padding(12.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(w.second, Modifier.weight(1f))
                            Text("🔊", Modifier.clickable { speaker.say(w.second, enId) }.padding(12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GrammarTab() {
    LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(grammar) { g ->
            var open by remember { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().clickable { open = !open }) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(g.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    if (open) {
                        Text(g.rule)
                        g.ex.forEach { Text("• ${it.first}\n   ${it.second}") }
                    } else Text("Ketuk untuk membuka", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun Percakapan() {
    var cat by remember { mutableStateOf(phrases.keys.first()) }
    Column(Modifier.padding(12.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(phrases.keys.toList()) { k ->
                FilterChip(selected = cat == k, onClick = { cat = k }, label = { Text(k) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 12.dp)) {
            items(phrases.getValue(cat)) { ph ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ph.en, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(ph.id)
                        }
                        Column {
                            Text("🔊 EN", Modifier.clickable { speaker.say(ph.en, false) }.padding(6.dp), fontSize = 12.sp)
                            Text("🔊 ID", Modifier.clickable { speaker.say(ph.id, true) }.padding(6.dp), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Latihan(p: Progress) {
    var lv by remember { mutableStateOf<String?>(null) }
    val l = lv
    if (l == null) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Pilih tingkatan", style = MaterialTheme.typography.titleLarge)
            levels.forEach { (n, qs) ->
                Card(Modifier.fillMaxWidth().clickable { lv = n }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(n, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("${qs.size} soal • skor terbaik ${p.best(n)}/${qs.size}")
                    }
                }
            }
        }
    } else Quiz(l, p) { lv = null }
}

@Composable
fun Quiz(level: String, p: Progress, onExit: () -> Unit) {
    val qs = levels.getValue(level)
    var i by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(-1) }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (i >= qs.size) {
            Text("Selesai! 🎉", style = MaterialTheme.typography.headlineSmall)
            Text("Skor $score / ${qs.size}")
            Button(onClick = onExit) { Text("Kembali") }
        } else {
            val q = qs[i]
            Text("$level • soal ${i + 1}/${qs.size}", fontSize = 12.sp)
            Text(q.q, style = MaterialTheme.typography.titleMedium)
            q.opts.forEachIndexed { k, o ->
                val c = when {
                    sel < 0 -> Color(0xFF334155)
                    k == q.ans -> Color(0xFF2E7D32)
                    k == sel -> Color(0xFFC62828)
                    else -> Color(0xFF334155)
                }
                Button(onClick = { if (sel < 0) { sel = k; if (k == q.ans) score++ } }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = c, contentColor = Color.White)) { Text(o) }
            }
            if (sel >= 0) Button(onClick = { i++; sel = -1; if (i >= qs.size) p.save(level, score) }) {
                Text(if (i + 1 >= qs.size) "Lihat hasil" else "Lanjut")
            }
        }
    }
}

@Composable
fun Progres(p: Progress) {
    val total = levels.values.sumOf { it.size }
    val got = levels.entries.sumOf { p.best(it.key) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Progres Belajar", style = MaterialTheme.typography.titleLarge)
        Text("Total: ${got * 100 / total}%", color = MaterialTheme.colorScheme.primary)
        levels.forEach { (n, qs) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(n, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { p.best(n).toFloat() / qs.size }, Modifier.fillMaxWidth())
                    Text("Skor terbaik ${p.best(n)}/${qs.size} • dikerjakan ${p.tries(n)}x", fontSize = 12.sp)
                }
            }
        }
    }
}
