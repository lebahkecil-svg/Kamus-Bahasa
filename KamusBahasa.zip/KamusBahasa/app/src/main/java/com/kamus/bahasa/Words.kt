package com.kamus.bahasa

private const val RAW = """
book=buku;water=air;house=rumah;friend=teman;food=makanan;school=sekolah;family=keluarga;mother=ibu;father=ayah;child=anak;man=laki-laki;woman=perempuan;
car=mobil;motorcycle=sepeda motor;road=jalan;city=kota;village=desa;market=pasar;shop=toko;fuel station=SPBU;fuel=bahan bakar;gasoline=bensin;oil=minyak;
money=uang;price=harga;customer=pelanggan;employee=karyawan;boss=atasan;work=pekerjaan;office=kantor;phone=telepon;table=meja;chair=kursi;door=pintu;
window=jendela;room=kamar;kitchen=dapur;bed=tempat tidur;day=hari;night=malam;morning=pagi;afternoon=siang;evening=sore;week=minggu;month=bulan;year=tahun;
time=waktu;name=nama;number=nomor / angka;color=warna;sun=matahari;rain=hujan;wind=angin;fire=api;tree=pohon;sea=laut;mountain=gunung;river=sungai;
animal=hewan;dog=anjing;cat=kucing;bird=burung;fish=ikan;rice=nasi;bread=roti;egg=telur;chicken=ayam;meat=daging;fruit=buah;vegetable=sayuran;
coffee=kopi;tea=teh;milk=susu;sugar=gula;salt=garam;doctor=dokter;hospital=rumah sakit;medicine=obat;health=kesehatan;problem=masalah;question=pertanyaan;
answer=jawaban;idea=ide;story=cerita;language=bahasa;word=kata;sentence=kalimat;letter=surat / huruf;picture=gambar;music=musik;game=permainan;
gift=hadiah;dream=mimpi;life=kehidupan;world=dunia;country=negara;
eat=makan;drink=minum;go=pergi;come=datang;buy=membeli;sell=menjual;help=membantu;love=mencintai;read=membaca;write=menulis;speak=berbicara;
understand=mengerti;learn=belajar;teach=mengajar;sleep=tidur;walk=berjalan;run=berlari;sit=duduk;stand=berdiri;open=membuka;close=menutup;give=memberi;
take=mengambil;see=melihat;hear=mendengar;think=berpikir;know=mengetahui;want=ingin;need=membutuhkan;like=menyukai;make=membuat;use=menggunakan;
find=menemukan;ask=bertanya;wait=menunggu;call=memanggil / menelepon;pay=membayar;cook=memasak;clean=membersihkan;wash=mencuci;play=bermain;
sing=bernyanyi;bring=membawa;send=mengirim;start=memulai;finish=menyelesaikan;forget=melupakan;remember=mengingat;try=mencoba;live=tinggal / hidup;
big=besar;small=kecil;happy=senang;sad=sedih;fast=cepat;slow=lambat;good=baik;bad=buruk;new=baru;old=tua / lama;hot=panas;cold=dingin;easy=mudah;
difficult=sulit;cheap=murah;expensive=mahal;beautiful=cantik / indah;dirty=kotor;full=penuh;empty=kosong;near=dekat;far=jauh;tall=tinggi;short=pendek;
heavy=berat;light=ringan;hungry=lapar;tired=lelah;sick=sakit;busy=sibuk;ready=siap;safe=aman;free=gratis / bebas;important=penting;strong=kuat;weak=lemah;
today=hari ini;tomorrow=besok;yesterday=kemarin;now=sekarang;always=selalu;never=tidak pernah;often=sering;sometimes=kadang-kadang;here=di sini;
there=di sana;very=sangat;because=karena;but=tetapi;and=dan;or=atau;with=dengan;without=tanpa;please=tolong;thank you=terima kasih;sorry=maaf;yes=ya;no=tidak
"""

val baseWords: List<Pair<String, String>> = RAW.replace("\n", "").split(";")
    .map { it.trim() }.filter { it.contains("=") }
    .map { it.substringBefore("=").trim() to it.substringAfter("=").trim() }

var words: List<Pair<String, String>> = baseWords

fun loadWords(c: android.content.Context): List<Pair<String, String>> = try {
    val extra = c.assets.open("dict.tsv").bufferedReader().useLines { ls ->
        ls.mapNotNull { l ->
            val p = l.split('\t')
            if (p.size >= 2 && p[0].isNotBlank() && p[1].isNotBlank()) p[0] to p[1] else null
        }.toList()
    }
    (baseWords + extra).distinctBy { it.first.lowercase() + "|" + it.second.lowercase() }
} catch (e: Exception) {
    baseWords
}
