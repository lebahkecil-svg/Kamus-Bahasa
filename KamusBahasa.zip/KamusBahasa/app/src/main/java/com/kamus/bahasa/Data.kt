package com.kamus.bahasa

data class Grammar(val title: String, val rule: String, val ex: List<Pair<String, String>>)
data class Phrase(val en: String, val id: String)
data class Q(val q: String, val opts: List<String>, val ans: Int)


val grammar = listOf(
    Grammar("Simple Present", "Dipakai untuk kebiasaan & fakta. Rumus: S + V1 (+s/es untuk he/she/it).",
        listOf("I drink coffee every morning." to "Saya minum kopi setiap pagi.", "She works at a station." to "Dia bekerja di sebuah SPBU.")),
    Grammar("Present Continuous", "Kejadian yang sedang berlangsung. Rumus: S + am/is/are + V-ing.",
        listOf("They are eating now." to "Mereka sedang makan sekarang.", "I am reading a book." to "Saya sedang membaca buku.")),
    Grammar("Simple Past", "Kejadian yang sudah selesai. Rumus: S + V2 (did + V1 untuk negatif/tanya).",
        listOf("He went to school yesterday." to "Dia pergi ke sekolah kemarin.", "I did not see her." to "Saya tidak melihatnya.")),
    Grammar("Simple Future", "Rencana/prediksi. Rumus: S + will + V1.",
        listOf("We will come tomorrow." to "Kami akan datang besok.", "It will rain tonight." to "Nanti malam akan hujan.")),
    Grammar("Present Perfect", "Aksi yang berhubungan dengan sekarang. Rumus: S + have/has + V3.",
        listOf("I have finished my work." to "Saya sudah menyelesaikan pekerjaan saya.", "She has lived here for 5 years." to "Dia sudah tinggal di sini selama 5 tahun.")),
    Grammar("Articles: a / an / the", "a + bunyi konsonan, an + bunyi vokal, the untuk hal yang sudah spesifik.",
        listOf("a book, an apple, the sun" to "sebuah buku, sebuah apel, matahari itu")),
    Grammar("Modal Verbs", "can (bisa), must (harus), should (sebaiknya), may (boleh). Rumus: S + modal + V1.",
        listOf("You should rest." to "Kamu sebaiknya istirahat.", "Can I help you?" to "Bisa saya bantu?"))
)

val phrases = linkedMapOf(
    "Salam" to listOf(Phrase("Good morning!", "Selamat pagi!"), Phrase("How are you?", "Apa kabar?"),
        Phrase("Nice to meet you.", "Senang bertemu denganmu."), Phrase("See you later.", "Sampai jumpa nanti.")),
    "Belanja" to listOf(Phrase("How much is this?", "Berapa harga ini?"), Phrase("Can I have a discount?", "Boleh saya minta diskon?"),
        Phrase("I'll take it.", "Saya ambil ini."), Phrase("Do you accept cards?", "Apakah menerima kartu?")),
    "Perjalanan" to listOf(Phrase("Where is the bus station?", "Di mana terminal bus?"), Phrase("How far is it?", "Seberapa jauh?"),
        Phrase("Please fill it up.", "Tolong isi penuh."), Phrase("I am lost.", "Saya tersesat.")),
    "Makan" to listOf(Phrase("I would like to order.", "Saya ingin memesan."), Phrase("The bill, please.", "Tolong tagihannya."),
        Phrase("It's delicious!", "Ini enak sekali!"), Phrase("No spicy, please.", "Tolong jangan pedas.")),
    "Darurat" to listOf(Phrase("Help me, please!", "Tolong saya!"), Phrase("Call an ambulance.", "Panggil ambulans."),
        Phrase("I need a doctor.", "Saya butuh dokter."), Phrase("I don't understand.", "Saya tidak mengerti."))
)

val levels = linkedMapOf(
    "Pemula" to listOf(
        Q("Arti kata 'water' adalah...", listOf("api", "air", "angin"), 1),
        Q("I ___ a student.", listOf("is", "are", "am"), 2),
        Q("She ___ coffee every day.", listOf("drink", "drinks", "drinking"), 1),
        Q("'Selamat pagi' dalam bahasa Inggris:", listOf("Good night", "Good morning", "Good bye"), 1),
        Q("___ apple (a / an)", listOf("a", "an", "the"), 1)),
    "Menengah" to listOf(
        Q("They ___ eating now.", listOf("is", "are", "was"), 1),
        Q("Yesterday, I ___ to the market.", listOf("go", "goes", "went"), 2),
        Q("We ___ come tomorrow.", listOf("will", "did", "have"), 0),
        Q("He didn't ___ the news.", listOf("saw", "see", "seen"), 1),
        Q("'Berapa harga ini?'", listOf("What is this?", "How much is this?", "Where is this?"), 1)),
    "Mahir" to listOf(
        Q("I ___ finished my work.", listOf("has", "have", "am"), 1),
        Q("She has lived here ___ 2020.", listOf("for", "since", "during"), 1),
        Q("You ___ see a doctor. (saran)", listOf("must", "should", "can"), 1),
        Q("If it rains, I ___ stay home.", listOf("will", "would", "did"), 0),
        Q("The book ___ by him. (pasif)", listOf("wrote", "was written", "writes"), 1))
)
