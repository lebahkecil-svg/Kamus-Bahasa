import json, urllib.request, tarfile, io, os, sys
import xml.etree.ElementTree as ET

OUT = "KamusBahasa/app/src/main/assets/dict.tsv"
FALLBACK = "https://download.freedict.org/dictionaries/eng-ind/2024.11.01/freedict-eng-ind-2024.11.01.src.tar.xz"

def get(u):
    return urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "kamus-build"}), timeout=180).read()

def ln(t):
    return t.rsplit("}", 1)[-1]

def find_url():
    try:
        db = json.loads(get("https://freedict.org/freedict-database.json"))
        d = next(x for x in db if x.get("name") == "eng-ind")
        for r in d["releases"]:
            if r.get("platform") == "src":
                return r.get("URL") or r.get("url")
    except Exception as ex:
        print("database.json gagal:", ex)
    return FALLBACK

try:
    url = find_url()
    print("Unduh:", url)
    tf = tarfile.open(fileobj=io.BytesIO(get(url)), mode="r:*")
    m = next(x for x in tf.getmembers() if x.name.endswith(".tei"))
    root = ET.parse(tf.extractfile(m)).getroot()
    rows = set()
    for e in root.iter():
        if ln(e.tag) != "entry":
            continue
        orth, trans, allq = None, [], []
        for x in e.iter():
            t = ln(x.tag)
            if t == "orth" and orth is None:
                orth = (x.text or "").strip()
            elif t == "cit":
                for q in x.iter():
                    if ln(q.tag) == "quote" and q.text:
                        (trans if x.get("type") == "trans" else allq).append(q.text.strip())
        for tr in (trans or allq):
            if orth and tr and "\t" not in orth + tr and len(orth) < 40 and len(tr) < 60:
                rows.add((orth, tr))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        for a, b in sorted(rows, key=lambda r: r[0].lower()):
            f.write(a + "\t" + b + "\n")
    print("Selesai:", len(rows), "pasangan kata")
except Exception as ex:
    print("PERINGATAN: kamus tambahan gagal dibuat, memakai kosakata bawaan.", ex)
    sys.exit(0)
